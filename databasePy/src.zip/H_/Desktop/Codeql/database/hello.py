import os

# Demander à l'utilisateur de saisir un nombre
user_input = input("Veuillez entrer un nombre : ")

# Utiliser l'entrée utilisateur dans une commande fictive
os.system(f"echo {user_input}")
